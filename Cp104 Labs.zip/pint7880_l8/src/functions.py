"""
------------------------------------------------------------------------
Functions
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-08"
------------------------------------------------------------------------
"""

from random import randint

def get_weekday_name(d):
    """
    -------------------------------------------------------
    Returns the name of a day of the week given its number.
    Use: name = get_weekday_name(d)
    -------------------------------------------------------
    Parameters:
        d - day of week number (1 <= int <= 7)
    Returns:
        name - matching day of the week, 1 = "Sunday", 7 = "Saturday" (str)
    -------------------------------------------------------
    """
    
    days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
    
    name = days[d-1]
   
    return name

        
def get_lotto_numbers(n, low, high):
    """
    -------------------------------------------------------
    Generates a sorted list of unique lottery numbers.
    Requires import: from random import randint
    Use: numbers = get_lotto_numbers(n, low, high)
    -------------------------------------------------------
    Parameters:
        n - number of lottery numbers to generate (int > 0)
        low - low value of the lottery number range (int >= 0)
        high - high value of the lottery number range (int > low)
    Returns:
        numbers - a list of unique random lottery numbers (list of int)
    -------------------------------------------------------
    """
    numbers=[]
    

    
    while len(numbers)<n:
        value = randint(low,high)
        if value not in numbers:
            numbers.append(value)
        
    return numbers
    
def many_search(a, v):
    """
    -------------------------------------------------------
    Searches through a for the value v and returns a list of
    all indexes of its occurrence.
    Use: indexes = many_search(a, v)
    -------------------------------------------------------
    Parameters:
        a - a list of values (list of ?).
        v - can be compared to values in a (?).
    Returns:
        indexes - a list of indexes of the location of v in a,
            [] if not found (list of int).
    -------------------------------------------------------
    """
    indexes=[]
    for x in range(len(a)):
        if v == a[x]:
            indexes.append(x)
    
    return indexes

def union(source1, source2):
    """
    -------------------------------------------------------
    Returns a list that is the union of the contents of source1 and source2.
    Every element that appears at least once in either source1 and source2
    must appear once and only once in target.
    Use: target = union(source1, source2)
    -------------------------------------------------------
    Parameters:
        source1 - a list (list of ?)
        source2 - a list (list of ?)
    Returns:
        target - the union of source1 and source2 (list of ?)
    -------------------------------------------------------
    """
    
    target = []
    
    for x in range(len(source1)):
        
        if source1[x] not in target:
            target.append(source1[x])
        
    for y in range(len(source1)):
        
        value2 = source2[y]
    
    
            
            
    
    
    
        
    
    
    

           
       
    
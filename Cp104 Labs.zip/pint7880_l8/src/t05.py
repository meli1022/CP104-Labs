"""
------------------------------------------------------------------------
Question 5
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-08"
------------------------------------------------------------------------
"""

import functions

n = int(input("Number of values:"))
low = int(input("Low Value:"))
high = int(input("High Value:"))


numbers = functions.get_lotto_numbers(n, low, high)

for i in range(1):
    
    print (sorted(numbers))
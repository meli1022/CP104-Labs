"""
------------------------------------------------------------------------
Question 2
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-29"
------------------------------------------------------------------------
"""
import functions


rows = int(input("Number of rows:"))
           
cols = int(input("Number of columns:"))


matrix = functions.generate_matrix_char(rows, cols)

print(matrix)
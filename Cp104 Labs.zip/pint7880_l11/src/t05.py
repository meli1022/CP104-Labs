"""
------------------------------------------------------------------------
Question 5
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-29"
------------------------------------------------------------------------
"""
import functions
from functions import print_matrix_char

word_list = ["cat", "dog", "big"]



matrix = functions.words_to_matrix(word_list)
print(matrix)

print_matrix_char(matrix)
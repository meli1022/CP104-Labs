"""
------------------------------------------------------------------------
Question 7
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-25"
------------------------------------------------------------------------
"""
import functions

width = int(input("Enter width in characters:"))
char = input ("Enter the draw character:")


output = functions.draw_arrow(width, char)

print (output)
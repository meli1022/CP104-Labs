"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-25"
------------------------------------------------------------------------
"""
import functions

age = int(input("Enter the worker's age:"))
salary = float(input("Enter worker's salary:"))
increase = float(input("Enter the yearly raise (%):"))


print ("Age    Salary")
print ("-------------")

output = functions.retirement(age, salary, increase)
print (output)
"""
------------------------------------------------------------------------
Question 10
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-25"
------------------------------------------------------------------------
"""
import functions

burnt_per_minute = float(input("Enter calories burned per minute:"))
start = int(input("Enter beginning number of minutes:"))
end = int(input("Enter ending number of minutes:"))
inc = int(input("Enter the increment in minutes:"))


output = functions.treadmill(burnt_per_minute, start, end, inc)


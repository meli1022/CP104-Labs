"""
------------------------------------------------------------------------
Question 1
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-08"
------------------------------------------------------------------------
"""
import functions

d = int(input("Enter an integer between 1 and 7:"))

name = functions.get_weekday_name(d)

for i in range(1):
    
    print (name)
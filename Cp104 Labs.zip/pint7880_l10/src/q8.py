"""
------------------------------------------------------------------------
Question 8
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-22"
------------------------------------------------------------------------
"""

import functions

fv = open("numbers.txt", "r+" ,encoding="utf-8")

print("file 'numbers.txt' open for reading and writing")

num  = functions.append_increment(fv)

print("{} is appended". format(num))
"""
------------------------------------------------------------------------
Question 14
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-22"
------------------------------------------------------------------------
"""

import functions

fv = open("words.txt", "a" ,encoding="utf-8")

print("Copying 'words.txt' to 'new_words.txt'")

functions.append_increment(fv)


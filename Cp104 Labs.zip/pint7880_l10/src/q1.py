"""
------------------------------------------------------------------------
Question 1
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-22"
------------------------------------------------------------------------
"""
import functions

fv = open("customers.txt", "r" ,encoding="utf-8")

print("Find record n")
n = int(input("Enter a record number:"))

result = functions.customer_record(fv, n)

print(result)
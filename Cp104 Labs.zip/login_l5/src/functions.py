"""
------------------------------------------------------------------------
Functions Lab 5
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-11"
------------------------------------------------------------------------
"""
def closest(target, v1, v2):
    """
    -------------------------------------------------------
    Determines closest value of two values to a target value.
    Use: result = closest(target, v1, v2)
    -------------------------------------------------------
    Parameters:
        target - the target value (float)
        v1 - first comparison value (float)
        v2 - second comparison value (float)
    Returns:
        result - one of v1 or v2 that is closest to target,
          v1 is the value chosen if v1 and v2 are an equal
          distance from target (float)
    -------------------------------------------------------
    """
    if abs(target - v1) <= abs(target - v2):
        result = v1
    else:
        result = v2
    return result 

def is_leap(year):
   
    """
    -------------------------------------------------------
    Determines if a year is a leap year. Every year that is
    exactly divisible by four is a leap year, except for years
    that are exactly divisible by 100, but these centurial years
    are leap years if they are exactly divisible by 400. For
    example, the years 1700, 1800, and 1900 are not leap years,
    but the years 1600 and 2000 are.
    Use: result = is_leap(year)
    -------------------------------------------------------
    Parameters:
        year - a year (int > 0)
    Returns:
        result - True if year is a leap year,
            False otherwise (boolean)
    ------------------------------------------------------
    """
    
    if year % 4 == 0 and year % 100 != 0:
        result = True
    elif year % 100 == 0 and year % 400 == 0:
        result = True
    elif year % 100 == 0 and year % 400 != 0:
        result = False
    else:
        result =False
    return result

def richter(intensity):
    """
    -------------------------------------------------------
    Determines damage level given earthquake intensity measured
    on the Richter scale.
    Use: result = richter(intensity)
    -------------------------------------------------------
    Parameters:
        intensity - Richter scale number for severity of earthquake
            (float >= 0)
    Returns:
        result - description of earthquake damage (str)
    -------------------------------------------------------
    """
    
    if intensity < 5:
        result = "Little or no damage"
    elif intensity < 5.5:
        result = "Some damage"
    elif intensity < 6.5:
        result = "Serious damage: walls may crack or fall"
    elif intensity < 7.5:
        result = "Disaster: buildings may collapse"
    else:
        result = "Catastrophe: most buildings destroyed"
    return result
        
def pay_raise(status, years, salary):
    """
    -------------------------------------------------------
    Calculates pay raises for employees. Pay raises are based on:
    status: Full Time ('F)' or Part Time ('P')
    and years of service
    Raises are:
        5% for full time >= 10 years service
        1.5% for full time < 4 years service
        3% for part time > 10 years service
        1% for part time < 4 years service
        2% for all others
    Use: new_salary = pay_raise(status, years, salary)
    -------------------------------------------------------
    Parameters:
        status - employment type (str - 'F' or 'P')
        years - number of years employed (int > 0)
        salary - current salary (float > 0)
    Returns:
        new_salary - employee's new salary (float).
    -------------------------------------------------------
    """
    FULL_TIME = "F"
    PART_TIME = "P"
    
    FIRST_RAISE = salary + salary * 0.05
    SECOND_RAISE = salary + salary * 0.015
    THIRD_RAISE = salary + salary * 0.03
    FOURTH_RAISE = salary + salary * 0.01
    
    if status == FULL_TIME and years >= 10:
        new_salary = FIRST_RAISE
    elif status == FULL_TIME and years < 4:
        new_salary = SECOND_RAISE
    elif status == PART_TIME and years > 10:
        new_salary = THIRD_RAISE
    elif status == PART_TIME and years < 4:
        new_salary = FOURTH_RAISE
    else:
        new_salary = salary + salary * 0.02
   
    return new_salary
    
        
def fast_food():
    
    """
    -------------------------------------------------------
    Food order function.
    Prices:
        Burger: $6.00
        Wings: $8.00
        Fries combo: add $1.50
        Salad combo: add $2.00
    Use: price = fast_food()
    -------------------------------------------------------
    Returns:
        price - the price of one meal (float)
    -------------------------------------------------------
    """
    BURGER = 6.00
    WINGS = 8.00
    FRIES = 1.50
    SALAD = 2.00
    
    order = str(input ("Order B - burger or W - wings:"))
    
    if order == "B":
        price = BURGER
    else:
        price = WINGS

    ask_Combo = str(input ("Make it a combo? (Y/N):"))

    if ask_Combo == "Y":
        combo = str(input ("Add F - fries or S - salad:"))

        if combo == "F":
            price = price + FRIES
        else:
            price = price + SALAD
    
    return price


        
    
    
    
    
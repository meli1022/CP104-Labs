"""
------------------------------------------------------------------------
Question 4
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-11"
------------------------------------------------------------------------
"""
import functions

target = float(input("Enter target:"))
v1 = float(input("Enter v1:"))
v2 = float(input("Enter v2:"))
result = functions.closest(target, v1, v2)

print("Closest value to {:.1f} is {:.1f}".format (target,result))
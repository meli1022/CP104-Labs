"""
------------------------------------------------------------------------
Question 12
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-11"
------------------------------------------------------------------------
"""
import functions

status = str(input("Status:"))
years = int (input ("Years:"))
salary = float(input ("Salary:"))

new_salary = functions.pay_raise(status, years, salary)

print ("New Salary: {:,.2f}".format(new_salary))
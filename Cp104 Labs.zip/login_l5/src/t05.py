"""
------------------------------------------------------------------------
Question 5
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-11"
------------------------------------------------------------------------
"""

import functions
   
year = int(input("Enter a year (>0):"))

result = functions.is_leap(year)
        
if result == True:
    print ("{} is a leap year".format(year))
elif result == False:
    print ("{} is not a leap year".format(year))
    
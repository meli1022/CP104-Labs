"""
------------------------------------------------------------------------
Question 14
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-15"
------------------------------------------------------------------------
"""

import functions

s1 = input("Enter first string:")
s2 = input("Enter second string:")


d = functions.str_distance(s1, s2)

print(d)
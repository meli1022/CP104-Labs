"""
------------------------------------------------------------------------
Question 2
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-15"
------------------------------------------------------------------------
"""
import functions

url = input("Enter the website address:")

url_type = functions.url_categorize(url)

print(url_type)

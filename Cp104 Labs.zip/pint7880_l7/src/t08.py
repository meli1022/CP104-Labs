"""
------------------------------------------------------------------------
Question 8
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-01"
------------------------------------------------------------------------
"""
import functions


available = float(input("Monthly budget:"))

expenses, balance, status = functions.budget(available)

print ("Total expenses: ${}.".format(expenses))

print (balance)
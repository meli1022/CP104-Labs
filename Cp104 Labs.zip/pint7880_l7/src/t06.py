"""
------------------------------------------------------------------------
Question 6
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-11-01"
------------------------------------------------------------------------
"""
import functions

negatives, zeroes, positives = functions.num_categories()

print ("Number of negative values: {}".format(negatives))
print("Number of zeroes: {}".format(zeroes))
print("Number of positive values: {}".format(positives))
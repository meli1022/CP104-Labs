"""
------------------------------------------------------------------------
Question 11
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-04"
------------------------------------------------------------------------
"""
import functions

x1 = float(input("Enter first x:"))
y1 = float(input("Enter first y:"))
x2 = float(input("Enter second x:"))
y2 = float(input("Enter second y:"))

s = functions.slope(x1, y1, x2, y2)

print ("The slope is {:.1f}".format(s))







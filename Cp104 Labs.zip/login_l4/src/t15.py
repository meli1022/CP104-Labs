"""
------------------------------------------------------------------------
Question 15
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-04"
------------------------------------------------------------------------
"""
import functions

initial_seconds = int(input("Number of seconds:"))

days,hours,minutes,seconds = functions.time_split(initial_seconds)

print ("Days: {}, Hours: {}, Minutes: {}, Seconds: {}". format(days,hours,minutes,seconds))
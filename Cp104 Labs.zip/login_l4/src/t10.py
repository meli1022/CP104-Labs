"""
------------------------------------------------------------------------
Question 10
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2019-10-04"
------------------------------------------------------------------------
"""
import functions

size = int(input("Current population:"))
births = int(input("Average seconds between births:"))
deaths = int(input("Average seconds between deaths:"))
immigrants = int(input("Average seconds between immigrations:"))
years = int(input("Years in the future:"))

new_size = functions.population(size, births, deaths, immigrants, years)

print ("The new population will be {:,.0f}".format(new_size))
